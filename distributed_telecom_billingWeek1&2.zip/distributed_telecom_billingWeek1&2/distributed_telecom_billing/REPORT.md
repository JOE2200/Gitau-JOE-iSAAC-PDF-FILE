# Distributed Telecom Billing and Rating System

## Introduction

This project implements an initial distributed prototype for processing telecommunications usage records. A customer/workload generator submits voice, SMS, and data usage requests to a billing service. The billing service forwards each request to a rating service, which calculates a charge and returns the result. The prototype uses independent operating-system processes and TCP communication to demonstrate distributed-system fundamentals, then records performance measurements for a 1,000-request workload.

The implementation models a distributed system as **nodes + processes + resources + communication**. All nodes currently run on one computer and communicate over the loopback network interface (`127.0.0.1`); they are separate logical services and processes, but are not deployed across separate physical machines.

## Objectives

### Milestone 1 — Distributed Operating System Foundation

- Identify computational nodes and their responsibilities.
- Create independent server processes for the billing service and rating services.
- Demonstrate application-level process scheduling by distributing requests among rating services.
- Identify the computational and communication resources used by the system.
- Implement basic inter-node request/response communication.
- Relate the prototype to operating-system responsibilities such as process execution, CPU scheduling, memory management, and network I/O.

### Milestone 2 — Distributed Processing and Performance

- Distribute rating work across multiple rating services.
- Measure throughput, end-to-end latency, jitter, application-level request loss, CPU, memory, and request distribution.
- Record repeatable experimental results and consider where processing or communication may become a bottleneck.
- Compare configurations with one, two, and four rating nodes as intended by the experiment design. The results currently saved in the project cover only the two-node configuration, so a comparative scaling conclusion is not yet supported.

## System Architecture

```text
Node 1: Customer/workload generator
          |
          | TCP; newline-delimited JSON
          v
Node 2: Billing service and dispatcher
          |
          | TCP; newline-delimited JSON
          +------> Node 3: Rating service
          +------> Node 4: Rating service
          +------> Node 5: Rating service (available configuration)
          +------> Node 6: Rating service (available configuration)
          |
          +<------ Selected rating service returns charge
          |
          +------> Node 1 receives the response
```

The active configuration is set in `common/config.py`. It currently selects Node 3 and Node 4. Node 2 uses round-robin scheduling over the configured active rating services. The one-node baseline and four-node configuration are also described in the configuration, but must be selected and measured separately.

### Nodes, processes, and responsibilities

| Node | Responsibility | Process and endpoint |
|---|---|---|
| Node 1 | Creates seeded usage requests, sends them to billing, and collects responses for the experiment. | Workload code runs in the experiment runner; connects to `127.0.0.1:5002`. |
| Node 2 | Accepts billing requests, dispatches each to a rating service, and returns the response. | Independent Python server process at `127.0.0.1:5002`. |
| Nodes 3–6 | Calculate charges for voice, SMS, or data usage and return the result. | Each is an independent Python server process on ports 5003–5006; active nodes are launched according to configuration. |

The launcher starts Node 2 and the configured rating-node processes using Python subprocesses. Node 1's workload-generation function is run by the experiment program; it is not started as a separate server by the launcher. Each rating process uses the same rating rules: voice at 0.50 per usage unit, SMS at 1.00, and data at 2.00.

### Process model

The server processes each have their own process identifier, address space, and listening socket. The operating system creates and schedules those processes and manages their CPU time, memory, and network I/O. At the application level, Node 2's dispatcher selects the destination rating process in round-robin order. This application scheduling is separate from the operating system's scheduling of processes on CPU cores.

The workload generator currently submits requests one at a time. Each server accepts and processes one connection at a time. Consequently, the prototype demonstrates distribution across services, but the current workload is not a concurrent load test and does not demonstrate simultaneous request processing by a node.

### Resource model

- **Compute:** CPU time for billing, scheduling, and rating calculations.
- **Memory:** process memory used for request handling and service state.
- **Network resources:** loopback TCP connections, listening ports, socket buffers, and JSON request/response data.
- **Application capacity:** the number of requests the dispatcher and rating services can accept and process within the configured timeout.
- **Operating-system services:** process creation and termination, process scheduling, virtual memory, and TCP/IP networking.

## How the Milestones Were Achieved

### Milestone 1

The prototype identifies customer/workload generation, billing/dispatch, and rating as separate node roles. The launcher creates the billing and active rating servers as independent operating-system processes. The billing server and rating servers communicate over TCP using newline-delimited JSON, with the rating response travelling back through the billing server to the workload generator.

The design evolved from representing nodes as Python objects in one process. That approach did not provide separate operating-system processes or actual network communication. It was replaced with subprocess-launched TCP servers. Node 2's round-robin dispatcher provides a clear process-level model for allocating incoming rating requests to active services.

### Milestone 2

Node 2 distributes incoming rating requests among the active rating processes. The experiment runner generates 1,000 records with a fixed random seed, measures total workload duration and successful-request latency, and writes results to `results/experiment_results.csv`. The monitoring code derives:

- **Throughput:** successful requests divided by total experiment time.
- **Latency:** elapsed time from sending a request to receiving its response, including the billing and rating network path.
- **Jitter:** mean absolute difference between consecutive successful request latencies.
- **Application request loss:** failed requests divided by all attempted requests.
- **CPU and memory:** sampled CPU percentage and resident memory for the process running the performance monitor.
- **Load distribution:** successful requests completed by each selected rating node.

The saved data contains three 1,000-request runs, each with 1,000 successes and zero application-level failures. All three show an even split of 500 requests per active rating service:

| Run | Throughput (requests/s) | Average latency (ms) | Average jitter (ms) | Application request loss | CPU (%) | Memory (MB) | Node 3 / Node 4 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 43.74 | 22.84 | 40.19 | 0% | 0.00 | 29.38 | 500 / 500 |
| 2 | 39.38 | 25.37 | 45.74 | 0% | 0.00 | 29.16 | 500 / 500 |
| 3 | 43.49 | 22.98 | 41.41 | 0% | 0.00 | 29.13 | 500 / 500 |

These results show that the two active rating services received an even number of successful requests under the recorded workload. They do not show that adding rating nodes increases throughput or reduces latency, because equivalent one-node and four-node measurements are not present. The recorded CPU and memory values describe the experiment/monitor process, not the combined resource consumption of all server processes.

## Challenges and Solutions

| Challenge | Solution or current status |
|---|---|
| Modeling nodes as objects in one process did not provide independent processes or real inter-node communication. | Replaced the in-process model with Python subprocesses and TCP server processes. |
| Sending work to multiple rating services requires a scheduling policy. | Added round-robin selection in the Node 2 dispatcher and a configuration list of active rating nodes. |
| Performance claims need repeatable and measurable evidence. | Added a seeded 1,000-request workload, metric collection, CSV output, and a written experimental procedure. The current CSV provides repeat runs for two rating nodes, but not a complete configuration comparison. |
| “Packet loss” is distinct from application request failures. | The current prototype counts failed application requests; it does not capture network packets or measure packet-level loss. Treat the reported 0% as application request loss only. |
| Resource measurements can be mistaken for whole-system measurements. | The current monitor samples the experiment process. System-wide CPU/memory or per-node process measurements are needed before drawing conclusions about total resource use. |
| Localhost tests do not represent physical network conditions. | The current topology is useful for validating process boundaries and protocol flow. Testing on multiple hosts is a future step for measuring network effects under a real distributed deployment. |

## Design Justification

Using independent server processes makes process creation and service boundaries observable and enables communication through TCP rather than direct function calls. JSON provides a readable message format for the prototype, and newline framing marks the end of each request and response. A centralized billing/dispatcher node keeps workload routing simple, while round-robin scheduling is easy to reason about and makes request allocation measurable. The same rating service can be configured as a one-node baseline or scaled to two or four nodes without changing the request format or charging logic.

The prototype prioritizes clarity and reproducibility over production characteristics. In particular, its local deployment, serial request generation, serial connection handling, and current process-scoped resource monitoring constrain what can be concluded from its performance results.

## Conclusion

The project establishes a working foundation for a distributed telecom billing and rating system. It identifies service nodes, models independent server processes, allocates rating requests using round-robin scheduling, and exchanges request/response messages over TCP. Its experiment runner captures throughput, latency, jitter, application request loss, CPU, memory, and rating-node distribution.

The available measurements demonstrate a balanced 500/500 distribution across two active rating nodes and zero application-level request failures for three 1,000-request runs. They are not sufficient to claim a performance improvement from distribution: comparable one-node and four-node experiments are still required. A stronger next evaluation should run all three configurations under the same workload, record the active-node count with each result, generate concurrent traffic, measure resource use for each server or at system level, and use packet-level instrumentation if actual network packet loss is required.
